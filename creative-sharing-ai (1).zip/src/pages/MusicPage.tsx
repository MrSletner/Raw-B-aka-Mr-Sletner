import React from 'react';
import Header from '../components/Header';
import AlbumCard from '../components/AlbumCard';
import SpotifyEmbed from '../components/SpotifyEmbed';
import { discographyData } from '../data/discography';
import { discographyPart2 } from '../data/discography-part2';
import { discographyPart3 } from '../data/discography-part3';
import { discographyPart4 } from '../data/discography-part4';
const MusicPage = () => {
  const fullDiscography = [
    ...discographyData,
    ...discographyPart2,
    ...discographyPart3,
    ...discographyPart4
  ];

  return (
    <div>
      <Header title="Music" subtitle="Raw B Complete Discography" />
      <div className="p-4">
        {/* Spotify Artist Embeds */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-center mb-6">Listen on Spotify</h2>
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <SpotifyEmbed artistId="0Sp1zosqMCFPFVRLXKsOtm" />
            <SpotifyEmbed artistId="3crPCy4UbttDYa2QGchCy0" />
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {fullDiscography.map((album, index) => (
            <AlbumCard key={index} {...album} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default MusicPage;