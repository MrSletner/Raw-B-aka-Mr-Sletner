import Navigation from '@/components/Navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Palette, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Art = () => {
  const artworks = [
    { id: 1, title: "Blue Dreams", medium: "Digital Art", year: "2024" },
    { id: 2, title: "Silver Reflections", medium: "Mixed Media", year: "2023" },
    { id: 3, title: "Raw Expression", medium: "Acrylic", year: "2024" },
    { id: 4, title: "Urban Vibes", medium: "Street Art", year: "2023" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-slate-100">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-blue-800 mb-4 font-handwritten">
            Art Gallery
          </h1>
          <p className="text-xl text-blue-600 font-handwritten">
            Visual expressions and creative works by Raw B
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {artworks.map((artwork) => (
            <Card key={artwork.id} className="bg-white/80 backdrop-blur-sm border-blue-200 hover:shadow-lg transition-shadow group">
              <CardContent className="p-6">
                <div className="aspect-square bg-gradient-to-br from-blue-200 to-slate-300 rounded-lg mb-4 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Palette size={48} className="text-blue-600" />
                </div>
                
                <h3 className="text-xl font-bold text-blue-800 mb-2 font-handwritten">
                  {artwork.title}
                </h3>
                <div className="space-y-1 mb-4">
                  <p className="text-sm text-blue-600">Medium: {artwork.medium}</p>
                  <p className="text-sm text-blue-600">Year: {artwork.year}</p>
                </div>
                
                <Button className="w-full bg-blue-600 hover:bg-blue-700 font-handwritten">
                  <Eye size={16} className="mr-2" />
                  View Full Size
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Art;