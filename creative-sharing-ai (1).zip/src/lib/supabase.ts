import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://gsnvoykygswkjirthdks.supabase.co';
const supabaseKey = 'sb_publishable_8XvsuC5-7jW1n9ff4MMq3g_4hM_rnX5';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };