import React from 'react';
import Header from '../components/Header';
import YouTubeEmbed from '../components/YouTubeEmbed';
import { videoData } from '../data/videos';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { ExternalLink, Palette, Play } from 'lucide-react';

const MediaPage = () => {
  const artGalleries = [
    {
      id: 1,
      title: "The Vision: Echoes of Robert Sletner",
      description: "A comprehensive collection showcasing the artistic vision and creative journey",
      url: "https://mrsletner.com/galleries/1302927/the-vision-echoes-of-robert-sletner",
      type: "Gallery"
    }
  ];

  return (
    <div>
      <Header title="Media" subtitle="Art Galleries & Visual Content" />
      <div className="p-4 space-y-8">
        
        {/* Art Galleries Section */}
        <section>
          <div className="flex items-center gap-2 mb-6">
            <Palette className="text-purple-400" size={24} />
            <h2 className="text-2xl font-bold text-brand-light">Art Galleries</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {artGalleries.map((gallery) => (
              <Card key={gallery.id} className="bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
                <CardContent className="p-6">
                  <div className="aspect-video bg-gradient-to-br from-purple-600/20 to-blue-600/20 rounded-lg mb-4 flex items-center justify-center">
                    <Palette size={48} className="text-purple-400" />
                  </div>
                  
                  <h3 className="font-semibold text-brand-light mb-2 line-clamp-2">
                    {gallery.title}
                  </h3>
                  <p className="text-brand-light/70 text-sm mb-4 line-clamp-3">
                    {gallery.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="inline-block bg-purple-600 text-white text-xs px-2 py-1 rounded-full">
                      {gallery.type}
                    </span>
                    <Button 
                      size="sm" 
                      onClick={() => window.open(gallery.url, '_blank')}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <ExternalLink size={16} className="mr-1" />
                      View Gallery
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Videos Section */}
        <section>
          <div className="flex items-center gap-2 mb-6">
            <Play className="text-purple-400" size={24} />
            <h2 className="text-2xl font-bold text-brand-light">Videos</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videoData.slice(0, 9).map((video) => (
              <div key={video.id} className="bg-white/5 rounded-lg p-4 border border-white/10">
                <div className="mb-4">
                  <YouTubeEmbed videoId={video.videoId} title={video.title} />
                </div>
                <div>
                  <h3 className="font-semibold text-brand-light mb-2">{video.title}</h3>
                  <span className="inline-block bg-purple-600 text-white text-xs px-2 py-1 rounded-full">
                    {video.type}
                  </span>
                </div>
              </div>
            ))}
          </div>
          
          {videoData.length > 9 && (
            <div className="text-center mt-8">
              <p className="text-brand-light/70">
                Showing 9 of {videoData.length} videos. 
                <a href="/videos" className="text-purple-400 hover:text-purple-300 ml-2">
                  View all videos →
                </a>
              </p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default MediaPage;