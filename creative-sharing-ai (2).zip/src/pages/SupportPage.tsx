import React from 'react';
import Header from '../components/Header';

const SupportPage = () => {
  const supportOptions = [
    { 
      title: "Buy Me a Coffee", 
      description: "Support my music with a small donation",
      icon: "☕",
      action: "Donate",
      link: "https://ko-fi.com/rawbsletner"
    },
    {
      title: "Monthly Patron",
      description: "Get exclusive content and early access on Patreon",
      icon: "🌟",
      action: "Subscribe",
      link: "https://www.patreon.com/c/therealRawB"
    },
    {
      title: "Share My Music",
      description: "Help spread the word on social media",
      icon: "📢",
      action: "Share"
    },
    {
      title: "Leave a Review",
      description: "Rate my music on streaming platforms",
      icon: "⭐",
      action: "Review"
    }
  ];

  return (
    <div>
      <Header title="Support" subtitle="Help Me Create More Music" />
      <div className="p-4">
        <div className="mb-6 text-center">
          <p className="text-brand-light/70 text-sm">
            Your support helps me continue creating music and art. Every contribution makes a difference!
          </p>
        </div>

        <div className="space-y-4">
          {supportOptions.map((option, index) => (
            <div key={index} className="bg-white/5 rounded-lg p-4 border border-white/10">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-600 to-red-600 rounded-lg flex items-center justify-center">
                  <span className="text-xl">{option.icon}</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-brand-light">{option.title}</h3>
                  <p className="text-brand-light/70 text-sm">{option.description}</p>
                </div>
                <button 
                  className="bg-pink-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-pink-700 transition-colors"
                  onClick={() => option.link && window.open(option.link, '_blank')}
                >
                  {option.action}
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <p className="text-brand-light/50 text-xs">
            Thank you for supporting independent music! 🎵
          </p>
        </div>
      </div>
    </div>
  );
};

export default SupportPage;