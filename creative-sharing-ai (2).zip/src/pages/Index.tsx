import Navigation from '@/components/Navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Music, Palette, Video, Disc, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const Index = () => {
  const sections = [
    { path: '/music', title: 'Music', icon: Music, description: 'Original tracks and beats' },
    { path: '/art', title: 'Art', icon: Palette, description: 'Visual creations and artwork' },
    { path: '/videos', title: 'Videos', icon: Video, description: 'Music videos and performances' },
    { path: '/remix-center', title: 'Remix Center', icon: Disc, description: 'Download stems and upload remixes' },
    { path: '/support', title: 'Support', icon: HelpCircle, description: 'Get in touch and find help' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-slate-100">
      <Navigation />
      
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold text-blue-800 mb-6 font-handwritten">
            Raw B
          </h1>
          <p className="text-2xl text-blue-600 font-handwritten mb-8">
            Music • Art • Creativity
          </p>
          <p className="text-lg text-blue-700 max-w-2xl mx-auto font-handwritten">
            Welcome to the creative hub of Robert "Raw B" Sletner. Explore original music, 
            visual art, videos, and collaborate through the remix center.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <Card key={section.path} className="bg-white/80 backdrop-blur-sm border-blue-200 hover:shadow-xl transition-all hover:scale-105">
                <CardContent className="p-8 text-center">
                  <Icon size={48} className="mx-auto text-blue-600 mb-4" />
                  <h3 className="text-2xl font-bold text-blue-800 mb-3 font-handwritten">
                    {section.title}
                  </h3>
                  <p className="text-blue-600 mb-6 font-handwritten">
                    {section.description}
                  </p>
                  <Button asChild className="w-full bg-blue-600 hover:bg-blue-700 font-handwritten">
                    <Link to={section.path}>
                      Explore {section.title}
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Index;