import Navigation from '@/components/Navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Video } from 'lucide-react';
import YouTubeEmbed from '@/components/YouTubeEmbed';
import { videoData } from '@/data/videos';

const Videos = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-slate-100">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-blue-800 mb-4 font-handwritten">
            Video Gallery
          </h1>
          <p className="text-xl text-blue-600 font-handwritten">
            Music videos, performances, and behind-the-scenes content
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videoData.map((video) => (
            <Card key={video.id} className="bg-white/80 backdrop-blur-sm border-blue-200 hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-800 font-handwritten text-lg">
                  <Video size={20} />
                  {video.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <YouTubeEmbed videoId={video.videoId} title={video.title} />
                
                <div className="mt-4">
                  <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-handwritten">
                    {video.type}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Videos;