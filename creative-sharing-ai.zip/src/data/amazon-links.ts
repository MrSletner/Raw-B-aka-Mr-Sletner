// Amazon Music links for albums
export const amazonLinks = {
  "Tabula Rasa": "https://amazon.com/music/player/albums/B0DD4XBPRC?marketplaceId=ATVPDKIKX0DER&musicTerritory=US&ref=dm_sh_wAZKgKqFWkvQmYvJGCZNlHmRo",
  "Volume One": "https://amazon.com/music/player/albums/B0DCZYS6BD?marketplaceId=ATVPDKIKX0DER&musicTerritory=US&ref=dm_sh_BD8j6XoSG1iEGtD5doKNZw4BG",
  "Analyze and Interpret": "https://amazon.com/music/player/albums/B0DDQGWNKM?marketplaceId=ATVPDKIKX0DER&musicTerritory=US&ref=dm_sh_Y7eN5zxiOPrIjd6AN6v6SwAdg",
  "Return of the Nightflier": "https://amazon.com/music/player/albums/B0DFZ6MT8L?marketplaceId=ATVPDKIKX0DER&musicTerritory=US&ref=dm_sh_R6B527U1dFBl8jyFuNijT1B0E",
  "Cunning Linguist": "https://amazon.com/music/player/albums/B0FCDKBSBS?marketplaceId=ATVPDKIKX0DER&musicTerritory=US&ref=dm_sh_zqR02gn1OqewUkoQPefLhW5zP",
  "III Kings": "https://amazon.com/music/player/albums/B0FJDXX9H6?marketplaceId=ATVPDKIKX0DER&musicTerritory=US&ref=dm_sh_CcJ6TjFJ8NINrMXs53gPQ9yS1"
};