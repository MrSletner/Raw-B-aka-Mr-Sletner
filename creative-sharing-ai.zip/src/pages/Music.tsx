import Navigation from '@/components/Navigation';
import EnhancedAlbumCard from '@/components/EnhancedAlbumCard';
import PurchaseBanner from '@/components/PurchaseBanner';
import SpotifyEmbed from '@/components/SpotifyEmbed';
import { discographyData } from '@/data/discography';
import { discographyPart2 } from '@/data/discography-part2';
import { discographyPart3 } from '@/data/discography-part3';
import { discographyPart4 } from '@/data/discography-part4';
import { amazonLinks } from '@/data/amazon-links';

const Music = () => {
  // Import mockdata albums and normalize the data structure
  const { albums } = require('@/data/mockdata');
  
  // Normalize mockdata albums to match the standard structure
  const normalizedMockAlbums = albums.map((album: any) => ({
    title: album.title,
    artist: album.persona,
    year: album.year,
    coverUrl: album.coverArt,
    streamingUrl: album.albumPurchaseUrl,
    tracks: album.tracks?.map((track: any) => ({
      number: parseInt(track.id.split('-t')[1]),
      title: track.title,
      duration: track.duration
    })) || []
  }));
  
  // Combine all discography data, removing duplicates by title
  const allAlbums = [
    ...discographyData,
    ...discographyPart2,
    ...discographyPart3,
    ...discographyPart4,
    ...normalizedMockAlbums
  ];
  
  // Remove duplicates based on title
  const uniqueAlbums = allAlbums.filter((album, index, self) => 
    index === self.findIndex(a => a.title === album.title)
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-50 to-silver-100">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-navy-800 mb-4 font-lakki">
            Raw B Discography
          </h1>
          <p className="text-xl text-navy-600 font-ribeye">
            Complete collection spanning 2005-2020
          </p>
        </div>

        <PurchaseBanner />

        {/* Spotify Artist Embeds */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-navy-800 mb-6 text-center font-lakki">
            Listen on Spotify
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <SpotifyEmbed artistId="0Sp1zosqMCFPFVRLXKsOtm" />
            <SpotifyEmbed artistId="3crPCy4UbttDYa2QGchCy0" />
          </div>
        </div>

        <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-8">
          {uniqueAlbums.map((album, index) => (
            <EnhancedAlbumCard 
              key={index} 
              {...album} 
              amazonUrl={amazonLinks[album.title as keyof typeof amazonLinks]}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Music;