import React, { useState, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import RemixUploader from '@/components/RemixUploader';
import DrumSampler from '@/components/DrumSampler';
import EnhancedRemixSuggestions from '@/components/EnhancedRemixSuggestions';
import RemixTrackSelector from '@/components/RemixTrackSelector';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, Music, Users, Palette } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface RemixPack {
  id: string;
  title: string;
  description: string;
  track_count: number;
  download_count: number;
}

interface Track {
  number: number;
  title: string;
  duration: string;
}

const RemixCenter = () => {
  const [remixPacks, setRemixPacks] = useState<RemixPack[]>([]);
  const [selectedTrack, setSelectedTrack] = useState<{album: string, track: Track} | null>(null);

  useEffect(() => {
    loadRemixPacks();
  }, []);

  const loadRemixPacks = async () => {
    try {
      const { data } = await supabase
        .from('remix_packs')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (data) setRemixPacks(data);
    } catch (error) {
      console.error('Error loading remix packs:', error);
    }
  };

  const handleTrackSelect = (album: string, track: Track) => {
    setSelectedTrack({ album, track });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-slate-100">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <Palette className="text-white" size={32} />
            </div>
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-800 to-purple-800 bg-clip-text text-transparent mb-4">
            Remix Center
          </h1>
          <p className="text-xl text-blue-600 max-w-2xl mx-auto">
            Download stems from Raw B's discography, upload remixes, and get AI-powered suggestions
          </p>
        </div>

        {/* Selected Track Info */}
        {selectedTrack && (
          <div className="mb-8 p-4 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg border border-green-200">
            <div className="flex items-center gap-4">
              <Music className="text-green-600" size={24} />
              <div>
                <h3 className="font-bold text-green-800">
                  Selected: {selectedTrack.track.title}
                </h3>
                <p className="text-green-600">
                  From "{selectedTrack.album}" • {selectedTrack.track.duration}
                </p>
              </div>
              <Button 
                size="sm" 
                className="ml-auto bg-green-600 hover:bg-green-700"
              >
                <Download size={16} className="mr-1" />
                Download Stems
              </Button>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          <RemixTrackSelector onTrackSelect={handleTrackSelect} />
          <RemixUploader onUploadComplete={() => console.log('Upload complete')} />
        </div>

        {/* Drum Sampler */}
        <div className="mb-8">
          <DrumSampler />
        </div>

        <EnhancedRemixSuggestions 
          selectedTrack={selectedTrack}
          onSuggestionsGenerated={(suggestions) => {
            console.log('Generated suggestions:', suggestions);
          }}
        />

        {/* Community section */}
        <Card className="mt-8 bg-white/80 backdrop-blur-sm border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-800">
              <Users size={24} />
              Community Remixes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <Music className="mx-auto mb-4 text-blue-400" size={48} />
              <p className="text-blue-600 mb-4">
                Discover amazing remixes of Raw B's tracks created by the community
              </p>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Browse Community
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RemixCenter;