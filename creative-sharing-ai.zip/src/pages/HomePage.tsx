import React from 'react';
import Header from '../components/Header';

const HomePage = () => {
  return (
    <div>
      <Header />
      <div className="p-4">
        <div className="text-center mb-8">
          <div className="w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden">
            <img 
              src="https://d64gsuwffb70l.cloudfront.net/688636f674f7e3235ad7fe12_1753751314278_884afbf4.jpeg" 
              alt="RS Music Logo"
              className="w-full h-full object-cover"
            />
          </div>
          <h2 className="text-xl font-bold text-brand-light mb-2">Welcome</h2>
          <p className="text-brand-light/70">Explore my music, art, and creative projects</p>
        </div>
        
        <div className="space-y-4">
          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h3 className="font-semibold text-brand-light mb-2">Latest Release</h3>
            <p className="text-brand-light/70 text-sm">Check out my newest tracks in the Music section</p>
          </div>
          
          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h3 className="font-semibold text-brand-light mb-2">Remix Center</h3>
            <p className="text-brand-light/70 text-sm">Create your own remixes with AI-powered tools</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;