import { useEffect } from 'react';
import Navigation from '@/components/Navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail, MessageCircle, HelpCircle, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Support = () => {
  useEffect(() => {
    // Load Ko-fi script
    const script = document.createElement('script');
    script.src = 'https://storage.ko-fi.com/cdn/scripts/overlay-widget.js';
    script.onload = () => {
      if (typeof (window as any).kofiWidgetOverlay !== 'undefined') {
        (window as any).kofiWidgetOverlay.draw('rawbsletner', {
          'type': 'floating-chat',
          'floating-chat.donateButton.text': 'Donate',
          'floating-chat.donateButton.background-color': '#1e3a8a',
          'floating-chat.donateButton.text-color': '#fff'
        });
      }
    };
    document.head.appendChild(script);

    return () => {
      const existingScript = document.querySelector('script[src*="ko-fi"]');
      if (existingScript) {
        existingScript.remove();
      }
    };
  }, []);

  const handleKofiDonate = () => {
    window.open('https://ko-fi.com/rawbsletner', '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-light-blue via-white to-silver">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold text-navy mb-4 font-heading drop-shadow-lg">
            Support & Contact
          </h1>
          <p className="text-2xl text-blue font-body">
            Get in touch with Raw B
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          <Card className="bg-white/90 backdrop-blur-sm border-2 border-navy/20 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-navy font-heading text-xl">
                <Heart size={24} className="text-blue" />
                Support Raw B
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-blue mb-4 font-body">
                Help support the music and art with a donation
              </p>
              <Button 
                onClick={handleKofiDonate}
                className="w-full bg-navy hover:bg-blue text-white font-body shadow-md"
              >
                Donate on Ko-fi
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/90 backdrop-blur-sm border-2 border-navy/20 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-navy font-heading text-xl">
                <Mail size={24} className="text-blue" />
                Email
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-blue mb-4 font-body">
                For business inquiries and collaborations
              </p>
              <Button className="w-full bg-navy hover:bg-blue text-white font-body shadow-md">
                Send Email
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/90 backdrop-blur-sm border-2 border-navy/20 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-navy font-heading text-xl">
                <MessageCircle size={24} className="text-blue" />
                Social Media
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-blue mb-4 font-body">
                Follow for updates and behind-the-scenes content
              </p>
              <Button className="w-full bg-navy hover:bg-blue text-white font-body shadow-md">
                Follow
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white/90 backdrop-blur-sm border-2 border-navy/20 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-navy font-heading text-xl">
                <HelpCircle size={24} className="text-blue" />
                FAQ
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-blue mb-4 font-body">
                Common questions and answers
              </p>
              <Button className="w-full bg-navy hover:bg-blue text-white font-body shadow-md">
                View FAQ
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Support;