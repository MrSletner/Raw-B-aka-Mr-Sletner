import { GoogleGenerativeAI } from "@google/generative-ai";

// For frontend React apps, use import.meta.env instead of process.env
const apiKey = import.meta.env.VITE_GOOGLE_GENAI_API_KEY;
if (!apiKey) {
  throw new Error("VITE_GOOGLE_GENAI_API_KEY environment variable not set");
}

const genAI = new GoogleGenerativeAI(apiKey);

export const generateBio = async (persona: string): Promise<string> => {
  const systemInstruction = `You are a creative writer specializing in edgy, short musician bios (under 75 words) for an independent artist from the Pacific Northwest. Your tone should match the artist's persona.
- For "Raw B", think gritty, urban hip-hop.
- For "Mr Sletner", think introspective, acoustic folk.
- For "Dookie Trackshoes", think quirky, experimental lo-fi beats.
- For "III Kings", think a confident, regal hip-hop group.`;
  
  const userPrompt = `Write a bio for the artist persona: ${persona}.`;

  try {
    const model = genAI.getGenerativeModel({ 
      model: "gemini-pro",
      systemInstruction 
    });

    const result = await model.generateContent({
      contents: [{ role: "user", parts: [{ text: userPrompt }] }],
      generationConfig: {
        temperature: 0.8,
        topP: 0.9,
        maxOutputTokens: 150,
      }
    });

    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Error generating bio with Gemini API:", error);
    return "Failed to generate bio. The creative sparks aren't flying right now.";
  }
};